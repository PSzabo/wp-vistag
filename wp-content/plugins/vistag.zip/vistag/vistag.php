<?php
/*
  Plugin Name: Vistag Plugin
  Plugin URI: https://github.com/...
  Description: Vistag is...
  Version: 1.0
  Author: Vistag, s.r.o.
  Author URI:  https://www.vistag.com
  License: GPLv2+
  License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

class Vistag{

  // Constructor
    function __construct() {

        add_action( 'admin_menu', array( $this, 'wpa_add_menu' ));
        add_action( 'admin_enqueue_scripts', array( $this, 'wpa_styles') );

        add_action('wp_head', array( $this, 'wp_head'));

        register_activation_hook( __FILE__, array( $this, 'wpa_install' ) );
        register_deactivation_hook( __FILE__, array( $this, 'wpa_uninstall' ) );
    }

    function wp_head()
    {
        echo '<script src="https://www.vistag.com/webservice/script.js?hash=22d18926f9"></script>';
    }

    /*
      * Actions perform at loading of admin menu
      */
    function wpa_add_menu() {
        add_menu_page( 'Vistag', 'Vistag', 'manage_options', 'vistag-settings', array(
            __CLASS__,
            'wpa_page_file_path'
        ), plugins_url('images/vistag-logo.png', __FILE__),'2.2.9');

        add_submenu_page(
            'vistag-settings',
            'Vistag' . ' Settings',
            'Settings',
            'manage_options',
            'vistag-settings', array(
            __CLASS__,
            'wpa_page_file_path'
        ));

        add_submenu_page(
            'vistag-settings',
            'Vistag' . ' Dashboard',
            ' Dashboard',
            'manage_options',
            'vistag-dashboard', array(
            __CLASS__,
            'wpa_page_file_path'
        ));
    }

    /*
     * Actions perform on loading of menu pages
     */
    function wpa_page_file_path() {

        $screen = get_current_screen();
        if ( strpos( $screen->base, 'vistag-settings' ) !== false ) {
            include( dirname(__FILE__) . '/includes/vistag-settings.php' );
        }
        else {
            include( dirname(__FILE__) . '/includes/vistag-dashboard.php' );
        }

    }

    /*
     * Actions perform on activation of plugin
     */
    function wpa_install() {



    }

    /*
     * Actions perform on de-activation of plugin
     */
    function wpa_uninstall() {



    }

    public function wpa_styles( $page ) {
        wp_enqueue_style( 'vistag-style', plugins_url('css/vistag-style.css', __FILE__));
    }

    public function saveEmail( $email ) {
        update_option( 'email', $email );
        return true;
    }

}

new Vistag();  
?>