<?php
    $vistag = new Vistag();

    if ( isset( $_POST["email"]) ) {

        if( $vistag->saveEmail($_POST["email"])){
            $update_message = '<div>Email address has been saved.</div>';
        }
    }

    $email  = get_option( "email" );

    if (isset($update_message)) echo $update_message;
?>
<div class="wrap">
    <h2 class='opt-title'><span id='icon-options-general' class='vistag-options'><img src="<?php echo plugins_url('vistag/images/vistag-logo.png');?>" alt=""></span>
        <?php echo __( 'Vistag Settings', 'wp-vistag' ); ?>
    </h2>
    <div style="padding-top: 20px;">
        <div style="font-size: 20px;line-height: 30px;">Fill your email address</div>
        <div style="font-size: 15px;line-height: 30px;">If you already have Vistag account, fill the email address of Vistag account</div>

        <br />
        <form action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>" method="post" name="settings_form" id="settings_form">
            <input type="email" name="email" value="<?=$email;?>" placeholder="E-mail" style="padding:10px 25px;width:30%;" />
            <br />
            <button type="submit" style="padding:10px 25px;width:100px;background:white;border:0;margin-top: 10px;">Save</button>
        </form>
    </div>
</div>