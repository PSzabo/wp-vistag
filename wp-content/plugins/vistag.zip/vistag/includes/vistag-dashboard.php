<div class="wrap">
    <h2 class='opt-title'><span id='icon-options-general' class='vistag-options'><img src="<?php echo plugins_url('vistag/images/vistag-logo.png');?>" alt=""></span>
        <?php echo __( 'Vistag Dashboard', 'wp-vistag' ); ?>
    </h2>
</div>